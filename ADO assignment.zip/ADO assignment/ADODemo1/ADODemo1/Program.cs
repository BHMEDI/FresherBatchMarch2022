﻿using System;
using System.Data.SqlClient;
using System.Configuration;

namespace ADODemo1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
                SqlConnection con;
                    //Database connection
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConString"].ConnectionString);
                con.Open();
                Console.WriteLine("Connected to Db");
                try
                {
                    char Selection;
                    do
                    {

                        Console.WriteLine("Choose Choice One : \n 1.Insertion \n 2.Retrive \n 3.Update \n 4.delete");
                        int Choice = int.Parse(Console.ReadLine());

                        switch (Choice)
                        {
                            case 1:
                                //Employee Data Insertion
                                Console.WriteLine("Enter Employee Id:");
                                int empid = int.Parse(Console.ReadLine());
                                Console.WriteLine("Enter Employee Name:");
                                string empname = Console.ReadLine();
                                Console.WriteLine("Enter Employee Email:");
                                string empemail = Console.ReadLine();
                                Console.WriteLine("Enter Employee Manager Id:");
                                int managerid = int.Parse(Console.ReadLine());
                                Console.WriteLine("Enter Employee Salary:");
                                int salary = int.Parse(Console.ReadLine());
                                string insertqery = "INSERT INTO Employee(Empid,EmpName,Salary,EmpEmail,Managerid) VALUES (" + empid + ",'" + empname + "','" + salary+ "','" + empemail + "','"+managerid+"')";
                                SqlCommand insertcomm = new SqlCommand(insertqery, con);
                                insertcomm.ExecuteNonQuery();
                                Console.WriteLine("data is Successfully inserted into a table");
                                break;
                            case 2:
                                 //Employee data retrivel
                                string retrive = "select *from Employee";
                                SqlCommand retrivecommand = new SqlCommand(retrive, con);
                                SqlDataReader empdata = retrivecommand.ExecuteReader();
                                while (empdata.Read())
                                {
                                    int eid = Convert.ToInt32(empdata["Empid"]);                                
                                    string ename = Convert.ToString(empdata["EmpName"]);
                                    string eemail = Convert.ToString(empdata["EmpEmail"]);
                                    string emanagerid = Convert.ToString(empdata["Managerid"]);
                                    string esalary = Convert.ToString(empdata["Salary"]);
                                    Console.WriteLine(eid + " " + ename + " " + eemail + " " + emanagerid + " " + esalary);

                                }
                                empdata.Close();
                                break;

                            case 3:
                                 //Employee Data Update
                                Console.WriteLine("Enter Employee Managerid to update :");
                                int mangeridupdate = int.Parse(Console.ReadLine());
                                Console.WriteLine("Enter Employee salary to update");
                                int SalaryUpdate = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Enter EmpId where you want to Update:");
                                int empidforupdate = int.Parse(Console.ReadLine());
                                string updateqruy = "UPDATE Employee SET Managerid = " + mangeridupdate +","+ "Salary= " + SalaryUpdate + " WHERE Empid = " + empidforupdate + "";
                                SqlCommand updatecommand = new SqlCommand(updateqruy, con);
                                updatecommand.ExecuteNonQuery();
                                Console.WriteLine("Data is Sucessfully Updated in to a table :");
                                break;
                            case 4:
                                 //Employee Data Deletion
                                Console.WriteLine("Enter Employeeid for delete:");
                                int empidfordelete = int.Parse(Console.ReadLine());
                                string deletequry = "DELETE FROM Employee where Empid=" + empidfordelete + "";
                                SqlCommand deletecommand = new SqlCommand(deletequry, con);
                                deletecommand.ExecuteNonQuery();
                                Console.WriteLine("Data is Sucessfully delete in a table");
                                break;

                            default:
                                Console.WriteLine("Invalid Input :");
                                break;

                        }
                        Console.WriteLine("Do You want to continue:(y/n)");
                        Selection = Convert.ToChar(Console.ReadLine());

                    } while (Selection == 'y');

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
                finally
                {
                    con.Close();

                }
                Console.ReadKey();
            
        }
    }
}
