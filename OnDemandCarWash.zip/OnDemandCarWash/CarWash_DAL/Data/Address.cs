﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarWash_DAL.Data
{
    public class Address
    {

        public string email { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLandmark { get; set; }
        public string AddressCity { get; set; }
        public string AddressState { get; set; }
        public string AddressPincode { get; set; }

    }
}
