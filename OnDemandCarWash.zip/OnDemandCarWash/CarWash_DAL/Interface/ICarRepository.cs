﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarWash_DAL.Models;
using CarWash_DAL.Data;

namespace CarWash_DAL.Interface
{
    public interface ICarRepository<T>
    {
           Task<string> AddCar(CarDetails car);
            Task<List<CarDetails>> GetCarDetails();
        Task<List<CarDetails>> GetCarsById(string email);

    }
}
