﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarWash_DAL.Models;
using CarWash_DAL.Data;

namespace CarWash_DAL.Interface
{
    public interface IUserRepository<T>
    {

        Task<T> CreateUser(UserProfile user);
        Task<string> AddAddress(Address address);
        Task<UserProfile> GetUserbyEmail(string email);
        Task<Address> GetAddressbyEmail(string email);



    }
}
