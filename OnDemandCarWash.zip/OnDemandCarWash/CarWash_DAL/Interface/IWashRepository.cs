﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarWash_DAL.Data;
using CarWash_DAL.Models;

namespace CarWash_DAL.Interface
{
    public interface IWashRepository<T>
    {
        Task<T> washRequest(washNow wash); 
        Task<string> addPackage(Package package);
    }
}
