﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarWash_DAL.Data;
using CarWash_DAL.Models;

namespace CarWash_DAL.Interface
{
    public interface ILoginRepository<T>
    {
        Task<CwuserProfile> CustomerLogin(Login customer);
        Task<CwuserProfile> WasherLogin(Login washer);


    }

}
