﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarWash_DAL.Data;

namespace CarWash_DAL.Interface
{
    public interface IWashRequest<T>
    {
        Task<List<WashRequest>> getWashRequestDetails();
    }
}
