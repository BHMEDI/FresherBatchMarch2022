﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarWash_DAL.Data;
using CarWash_DAL.Interface;
using CarWash_DAL.Models;
using Microsoft.EntityFrameworkCore;

namespace CarWash_DAL.Repository
{
    public class WashRepository : IWashRepository<CwwashNow>
    {
        private readonly CarWashDBContext carWashDatabaseContext;
        public WashRepository(CarWashDBContext _carWashDatabaseContext)
        {
            carWashDatabaseContext = _carWashDatabaseContext;
        }

        public async Task<string> addPackage(Package package)
        {

            var newPackage = new Cwpackage()
            {
                
                PackageName = package.PackageName,
                PackageDetails= package.PackageDetails,
                PackageCost=package.PackageCost


            };
            try
            {
                if (carWashDatabaseContext != null)
                {

                    await carWashDatabaseContext.Cwpackages.AddAsync(newPackage);
                    await carWashDatabaseContext.SaveChangesAsync();


                    return newPackage.PackageName;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }

        public async Task<CwwashNow> washRequest(washNow wash)
        {
            var user = await carWashDatabaseContext.CwuserProfiles.Where(x => x.UserEmail == wash.Email).FirstOrDefaultAsync();

            var washCar = new CwwashNow()
            {
                UserId= user.UserId,
               // WashNowRequestTime = wash.WashNowRequestTime,
                WashNowWashNotes = wash.WashNowWashNotes,
                WashNowCarLocation=wash.WashNowCarLocation,
                WashNowSelectedCar=wash.WashNowSelectedCar,
                PackageName= wash.packageName

            };
            try
            {
                if (carWashDatabaseContext != null)
                {
                  
                    await carWashDatabaseContext.CwwashNows.AddAsync(washCar);
                    await carWashDatabaseContext.SaveChangesAsync();


                    return washCar;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
    }
}
