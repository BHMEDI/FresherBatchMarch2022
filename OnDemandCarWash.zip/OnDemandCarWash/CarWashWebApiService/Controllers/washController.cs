﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarWash_BAL;
using CarWash_BAL.Services;
using CarWash_DAL.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CarWashWebApiService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class washController : ControllerBase
    {

        private readonly WashNowService washService;
        private readonly WashRequestService washRequestService;

        public washController(WashNowService _washService, WashRequestService _washRequestService)
        {
            washService = _washService;
            washRequestService = _washRequestService;
        }
        [HttpPost]
        [Route("WashNow")]
        public async Task<IActionResult> WashNow([FromBody] washNow wash)
        {

            await washService.washRequest(wash);
            return Ok(wash);
        }
        [HttpPost]
        [Route("addPackage")]
        public async Task<IActionResult> addPackage([FromBody] Package package)
        {

           var newPackage = await washService.addPackage(package);
            return Ok(newPackage);
        }
        [HttpGet]
        [Route("GetWashRequest")]
        public async Task<IActionResult> GetWashRequest()
        {
            var cars = await washRequestService.getWashRequestDetails();
            return Ok(cars);
        }

    }
}
