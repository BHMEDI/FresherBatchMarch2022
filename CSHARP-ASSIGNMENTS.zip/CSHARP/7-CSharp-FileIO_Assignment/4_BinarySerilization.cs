﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
namespace _7_CSharp_FileIO_Assignment
{
    [Serializable]
    public class Manger1
    {
        public int Empid { get; set; }
        public string Emp_name { get; set; }
        public int Basic_salary { get; set; }
        class Client4
        {
            public static void serailize(Manger1 mgr)
            {
                BinaryFormatter formatter = new BinaryFormatter();

                Stream stream = new FileStream(@"D:\bk\a.txt", FileMode.OpenOrCreate);//STREAM OBJECT
                formatter.Serialize(stream, mgr);//CALL SERIALIZE METHOD WITH BINARY FORMATTER 
                stream.Close();
            }
            public static void deserilize(Manger1 mgr)
            {
                BinaryFormatter formatter = new BinaryFormatter();//BINARY OBJECT
                Stream stream1 = new FileStream(@"D:\bk\a.txt", FileMode.Open, FileAccess.Read);//STREAM OBJECT
                mgr = (Manger1)formatter.Deserialize(stream1);//TO DESERIALIZE CALL BINARY FORMATTER WITH  DESERIALIZE AND CAST IT TO CORRECT TYPE
                Console.WriteLine(mgr.Empid);
                Console.WriteLine(mgr.Emp_name);
                Console.WriteLine(mgr.Basic_salary);
            }

            static void Main()
            {
                Manger1 mgr = new Manger1();
                Console.WriteLine("enter employid");
                mgr.Empid = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter employename");
                mgr.Emp_name = Console.ReadLine();
                Console.WriteLine("enter basic salary");
                mgr.Basic_salary = Convert.ToInt32(Console.ReadLine());
                serailize(mgr);
                deserilize(mgr);
                Console.ReadKey();

            }
        }
    }
}