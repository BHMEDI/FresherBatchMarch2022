﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;


namespace _7_CSharp_FileIO_Assignment
{
        public class Employee 
        {
            public int EmpNo;
            public string EmpName;
            public double Salary;
            public double HRA;
            public double TA;
            public double DA;
            public double PF;
            public double TDS;
            public double NetSalary;
            public double GrossSalary;

            public virtual double grossSalary()
            {
                if (Salary < 5000)
                {
                    HRA = ((Salary / 100) * 10);
                    TA = ((Salary / 100) * 5);
                    DA = ((Salary / 100) * 15);
                    GrossSalary = ((Salary) + (HRA + TA + DA));
                }
                else if (Salary < 10000)
                {
                    HRA = ((Salary / 100) * 15);
                    TA = ((Salary / 100) * 10);
                    DA = ((Salary / 100) * 20);
                    GrossSalary = ((Salary) + (HRA + TA + DA));
                }
                else if (Salary < 15000)
                {
                    HRA = ((Salary / 100) * 20);
                    TA = ((Salary / 100) * 15);
                    DA = ((Salary / 100) * 25);
                    GrossSalary = ((Salary) + (HRA + TA + DA));
                }
                else if (Salary < 20000)
                {
                    HRA = ((Salary / 100) * 25);
                    TA = ((Salary / 100) * 20);
                    DA = ((Salary / 100) * 30);
                    GrossSalary = ((Salary) + (HRA + TA + DA));
                }
                else if (Salary >= 20000)
                {
                    HRA = ((Salary / 100) * 25);
                    TA = ((Salary / 100) * 20);
                    DA = ((Salary / 100) * 35);
                    GrossSalary = ((Salary) + (HRA + TA + DA));
                }
                return GrossSalary;
            }
            public virtual void CalculateSalary()
            {
                PF = (GrossSalary / 100) * 10;
                TDS = (GrossSalary / 100) * 18;
            }

            public void DisplayDetails()
            {

            }

        }
       public class Maneger : Employee
        {
            public double Petrol_Allowance;
            public double Food_Allowance;
            public double Other_Allowance;

            public override double grossSalary()
            {
                base.grossSalary();
                Petrol_Allowance = ((Salary / 100) * 8);
                Food_Allowance = ((Salary / 100) * 13);
                Other_Allowance = ((Salary / 100) * 3);
                GrossSalary += (Petrol_Allowance + Food_Allowance + Other_Allowance);

                return GrossSalary;
            }

            public override void CalculateSalary()
            {
                base.CalculateSalary();
                NetSalary = (GrossSalary - (TDS + PF));

            }
            public new void DisplayDetails()
            {
                Console.WriteLine("enter manager id");
                EmpNo = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter manger name");
                EmpName = Console.ReadLine();
                Console.WriteLine("enter manger base salary");
                Salary = Convert.ToInt32(Console.ReadLine());
                grossSalary();
                CalculateSalary();
                Console.WriteLine("MangerGrossSalary {0}", GrossSalary);
                Console.WriteLine("\n");
                Console.WriteLine("MangerNetSalary {0}", NetSalary);
            }

       
    
    
        }
       public class MarketingExecutive : Employee
        {
            public int Kilometer;
            public int Travel_Allowence;
            public int Telephone_Allowence;

            public override double grossSalary()
            {
                base.grossSalary();

                Travel_Allowence = Kilometer * 5;
                Telephone_Allowence = 1000;
                GrossSalary += Travel_Allowence + Telephone_Allowence;
                return GrossSalary;
            }

            public override void CalculateSalary()
            {
                base.CalculateSalary();
                NetSalary = (GrossSalary - (TDS + PF));

            }
            public new void DisplayDetails()
            {
                Console.WriteLine("enter employee id");
                EmpNo = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter employee name");
                EmpName = Console.ReadLine();
                Console.WriteLine("enter employee base salary");
                Salary = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter kilometers travelled by employee");
                Kilometer = Convert.ToInt32(Console.ReadLine());
                grossSalary();
                CalculateSalary();
                Console.WriteLine("employeeGrossSalary {0}", GrossSalary);
                Console.WriteLine("\n");
                Console.WriteLine("employeeNetSalary {0}", NetSalary);
            }
        }
        class Client
        {
        public static void SerilizeData0(Employee employee)
        {
            FileStream fs = new FileStream(@"D:\bk\a.txt", FileMode.Create);
            XmlSerializer serializer = new XmlSerializer(typeof(Employee));
            serializer.Serialize(fs, employee);
            fs.Close();
        }
        public static void SerilizeData(Maneger maneger)
        {
            FileStream fs = new FileStream(@"D:\bk\c.txt", FileMode.Create);
            XmlSerializer serializer = new XmlSerializer(typeof(Maneger));
            serializer.Serialize(fs, maneger);
            fs.Close();
        }
            public static void SerilizeData1(MarketingExecutive marketingExecutive)
        {

            FileStream fileStream = new FileStream(@"D:\bk\d.txt", FileMode.Create)
            {

            };
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(MarketingExecutive));
            xmlSerializer.Serialize(fileStream, marketingExecutive);
            fileStream.Close();
           
        }
        
            static void Main()
            {
                Employee employee = new Employee();
                employee.DisplayDetails();
                SerilizeData0(employee);
                Maneger maneger = new Maneger();
                maneger.DisplayDetails();
                SerilizeData(maneger);
                Console.WriteLine("---------------------------------");
                MarketingExecutive marketingExecutive = new MarketingExecutive();
                marketingExecutive.DisplayDetails();
                SerilizeData1(marketingExecutive);
                Console.ReadLine();
            }
        }
}

