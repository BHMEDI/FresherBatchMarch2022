﻿using System;
using System.IO;

namespace _7_CSharp_FileIO_Assignment
{
    public class Class1
    {
        static void Main(string[] args)
        {
              String path = @"D:\bk";
  /*
  FOR CREATING DIRECTORIES
            */ 
  /*  DirectoryInfo fl = new DirectoryInfo(path);
               fl.Create();
               {
                   Console.WriteLine("Directory has been created");
               }*/
  //LIST OF subdirectries
            string[] myDirs = Directory.GetDirectories(path);
            Console.WriteLine("Directories:");
            foreach (var myDir in myDirs)
            {
                Console.WriteLine(myDir);
            }

  //FOR CREATING FILES
            /*  FileInfo file = new FileInfo(@"D:\bk\cd.txt\b.txt");
              file.Create();
              {
                  Console.WriteLine("filecreated");
              }*/
    //TO READ TEXT FILES FROM MENTIONED FILE SYSTEM 
            string text = File.ReadAllText(@"D:\bk\b.txt");
            Console.WriteLine(text);
            Console.ReadKey();
        }


    }
}
