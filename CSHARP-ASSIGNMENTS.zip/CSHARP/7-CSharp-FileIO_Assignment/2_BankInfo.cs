﻿using System;
using System.IO;

namespace _7_CSharp_FileIO_Assignment
{
    public delegate void Notify1();
    internal class ICICIBANK
    {
        public int Account_Number1;
        public string Customer_Name1;
        public int Balance1;
        public int Amount1;
        public event Notify1 ZeroBalance;
        public event Notify1 UnderBalance;
        public void Diposit1()
        {
            Console.WriteLine("enter account number");
            Account_Number1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter customer name");
            Customer_Name1 = Console.ReadLine();
            Console.WriteLine("enter amount to disposit");
            Balance1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("balance amount is" + ":" + Balance1);
        }
        public virtual void WithDraw1()
        {

            Console.WriteLine("enter amount to withdrawl");
            Amount1 = Convert.ToInt32(Console.ReadLine());

            if (Balance1 == 0)
            {
                OnZeroBalance();
            }

            else if (Amount1 > (Balance1 - 1000))
            {
                Onunderbalance();
            }
            else
            {
                Balance1 = Balance1 - Amount1;
                Console.WriteLine("your balance is" + ":" + Balance1 + "---" + "TRANSACTION SUCUSSFULL");

            }

        }
        protected virtual void OnZeroBalance()
        {
            ZeroBalance?.Invoke();
        }
        protected virtual void Onunderbalance()
        {
            UnderBalance?.Invoke();
        }
    }

    class ICICI :ICICIBANK
    {
        public static void Main()
        {
            ICICIBANK account = new ICICIBANK();
            account.ZeroBalance += z1_ZeroBalance;
            account.UnderBalance += z2_underbalace;
            account.Diposit1();
            account.WithDraw1();
           

            using (StreamWriter writer = new StreamWriter(@"D:\bk\b.txt"))
            {
                writer.WriteLine("Account_no"+":"+account.Account_Number1);
                writer.WriteLine("Customer_Name"+":"+account.Customer_Name1);
                writer.WriteLine("Account_balance"+":"+account.Balance1);

            }
            using(StreamReader reader = new StreamReader(@"D:\bk\b.txt"))
            {
                string s;
                
                {
                    s = reader.ReadLine();
                    Console.WriteLine(s);
                } while (s != null);
            }
            Console.ReadLine();

        }

        public static void z1_ZeroBalance()
        {
            Console.WriteLine("Transaction cannot be continued as balance is zero in Account ");
        }
        public static void z2_underbalace()
        {
            Console.WriteLine("Transaction cannot be continued as balance is insufficient");

        }
    }
}