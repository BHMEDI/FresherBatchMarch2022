﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6_CSharp__Delegates_Assignment
{
   
    
       // public delegate void EmployeeDelegate2();
        public delegate void MarketingExecutiveDelegate();
       
            public class Employee
            {
                protected int EmpNo;
                protected string EmpName;
                protected double Salary;
                protected double HRA;
                protected double TA;
                protected double DA;
                protected double PF;
                protected double TDS;
                protected double NetSalary;
                protected double GrossSalary;

                public virtual double grossSalary()
                {
                    if (Salary < 5000)
                    {
                        HRA = ((Salary / 100) * 10);
                        TA = ((Salary / 100) * 5);
                        DA = ((Salary / 100) * 15);
                        GrossSalary = ((Salary) + (HRA + TA + DA));
                    }
                    else if (Salary < 10000)
                    {
                        HRA = ((Salary / 100) * 15);
                        TA = ((Salary / 100) * 10);
                        DA = ((Salary / 100) * 20);
                        GrossSalary = ((Salary) + (HRA + TA + DA));
                    }
                    else if (Salary < 15000)
                    {
                        HRA = ((Salary / 100) * 20);
                        TA = ((Salary / 100) * 15);
                        DA = ((Salary / 100) * 25);
                        GrossSalary = ((Salary) + (HRA + TA + DA));
                    }
                    else if (Salary < 20000)
                    {
                        HRA = ((Salary / 100) * 25);
                        TA = ((Salary / 100) * 20);
                        DA = ((Salary / 100) * 30);
                        GrossSalary = ((Salary) + (HRA + TA + DA));
                    }
                    else if (Salary >= 20000)
                    {
                        HRA = ((Salary / 100) * 25);
                        TA = ((Salary / 100) * 20);
                        DA = ((Salary / 100) * 35);
                        GrossSalary = ((Salary) + (HRA + TA + DA));
                    }
                    return GrossSalary;
                }
                public virtual void CalculateSalary()
                {
                    PF = (GrossSalary / 100) * 10;
                    TDS = (GrossSalary / 100) * 18;
                }

               // public void DisplayDetails()
               // {

              //  }

            }
            class Maneger : Employee
            {
                private double Petrol_Allowance;
                private double Food_Allowance;
                private double Other_Allowance;

                public override double grossSalary()
                {
                    base.grossSalary();
                    Petrol_Allowance = ((Salary / 100) * 8);
                    Food_Allowance = ((Salary / 100) * 13);
                    Other_Allowance = ((Salary / 100) * 3);
                    GrossSalary += (Petrol_Allowance + Food_Allowance + Other_Allowance);

                    return GrossSalary;
                }

                public override void CalculateSalary()
                {
                    base.CalculateSalary();
                    NetSalary = (GrossSalary - (TDS + PF));

                }
                public  void DisplayDetails()
                {
                    Console.WriteLine("enter manager id");
                    EmpNo = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("enter manger name");
                    EmpName = Console.ReadLine();
                    Console.WriteLine("enter manger base salary");
                    Salary = Convert.ToInt32(Console.ReadLine());
                    grossSalary();
                    CalculateSalary();
                    Console.WriteLine("MangerGrossSalary {0}", GrossSalary);
                    Console.WriteLine("\n");
                    Console.WriteLine("MangerNetSalary {0}", NetSalary);
                }

            }
            class MarketingExecutive : Employee
            {
                private int Kilometer;
                private int Travel_Allowence;
                private int Telephone_Allowence;

                public override double grossSalary()
                {
                    base.grossSalary();

                    Travel_Allowence = Kilometer * 5;
                    Telephone_Allowence = 1000;
                    GrossSalary += Travel_Allowence + Telephone_Allowence;
                    return GrossSalary;
                }

                public override void CalculateSalary()
                {
                    base.CalculateSalary();
                    NetSalary = (GrossSalary - (TDS + PF));

                }
                public void DisplayDetails()
                {
                    Console.WriteLine("enter employee id");
                    EmpNo = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("enter employee name");
                    EmpName = Console.ReadLine();
                    Console.WriteLine("enter employee base salary");
                    Salary = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("enter kilometers travelled by employee");
                    Kilometer = Convert.ToInt32(Console.ReadLine());
                    grossSalary();
                    CalculateSalary();
                    Console.WriteLine("employeeGrossSalary {0}", GrossSalary);
                    Console.WriteLine("\n");
                    Console.WriteLine("employeeNetSalary {0}", NetSalary);
                }
            }
            class Client1
            {
                static void Main()
                {
                    Maneger maneger = new Maneger();
                   // EmployeeDelegate2 ad = new EmployeeDelegate2(maneger.DisplayDetails);
                    
                    Console.WriteLine("---------------------------------");
                    MarketingExecutive marketingExecutive = new MarketingExecutive();
                    MarketingExecutiveDelegate me = new MarketingExecutiveDelegate(marketingExecutive.DisplayDetails);
                    me += maneger.DisplayDetails;

                    // me += maneger.DisplayDetails;
                    me.Invoke();
                    Console.ReadLine();




                }

            }
        }

    
