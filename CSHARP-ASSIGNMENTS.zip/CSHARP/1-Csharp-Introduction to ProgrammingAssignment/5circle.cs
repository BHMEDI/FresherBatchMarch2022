﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1_Csharp_Introduction_to_ProgrammingAssignment
{
    internal class _5circle
    {
        static void Main(String[] args)
        {
            Circle();

        }
        static void Circle()
        {
            Console.WriteLine("enter radius of the circle");
            float r = Convert.ToInt32(Console.ReadLine());
            double C = 2 * 3.14 * r;
            double Area = 3.14 * r * r;
            Console.WriteLine("circumfernce of the circle {0}", C);
            Console.WriteLine("Area of the circle {0}", Area);
            Console.ReadKey();
        }
    }
}
