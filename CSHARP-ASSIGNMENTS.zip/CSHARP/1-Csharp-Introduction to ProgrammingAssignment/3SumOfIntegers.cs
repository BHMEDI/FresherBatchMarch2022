﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1_Csharp_Introduction_to_ProgrammingAssignment
{
    internal class _3SumOfIntegers
    {
        static void Main(String[] args)
        {
            SumOfIntegers();
        }
        static void SumOfIntegers()
        {
            int[] numbers = { 5, 6, 7, 8, 9 };

            Console.WriteLine(numbers.Sum());
            Console.ReadKey();

        }





    }
}
