﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1_Csharp_Introduction_to_ProgrammingAssignment
{
    enum BookType
    {
        Magazine,
        Novel,
        ReferenceBook,
        Miscellaneous
    }
    struct Books
    {
        public string title;
        public string booktype;
        public int price;
        public int book_id;

        public void Bookdetails()
        {
            Console.WriteLine("enter book title");
            title = Console.ReadLine();
            Console.WriteLine("enter  book id");
            book_id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter book price");
            price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter booktype");
            booktype = Console.ReadLine();
        }
        public void Displaydetails()
        {
            if (booktype == "Magazine")
            {
                Console.WriteLine("booktitle = {0}", title);
                Console.WriteLine("bookid = {0}", book_id);
                Console.WriteLine("bookprice = {0}", price);
                Console.WriteLine("booktype = {0}", BookType.Magazine.ToString());
            }

            else if (booktype == "Novel")
            {
                Console.WriteLine("booktitle = {0}", title);
                Console.WriteLine("bookid = {0}", book_id);
                Console.WriteLine("bookprice = {0}", price);
                Console.WriteLine("booktype={0}", BookType.Novel.ToString());
            }
           else if (booktype == "ReferenceBook")
            {
                Console.WriteLine("booktitle = {0}", title);
                Console.WriteLine("bookid = {0}", book_id);
                Console.WriteLine("bookprice = {0}", price);
                Console.WriteLine("booktype={0}", BookType.ReferenceBook.ToString());
            }
           else if (booktype == " Miscellaneous")
            {
                Console.WriteLine("booktitle = {0}", title);
                Console.WriteLine("bookid = {0}", book_id);
                Console.WriteLine("bookprice = {0}", price);
                Console.WriteLine("booktype={0}", BookType.Miscellaneous.ToString());
            }
            else
            {
                Console.WriteLine("invalid booktype");
            }
        
        }


    };
    class Client
    {
        static void Main()
        {
            Books obj1 = new Books();
            obj1.Bookdetails();
            obj1.Displaydetails();
            Console.ReadLine();

        }
    }
}
