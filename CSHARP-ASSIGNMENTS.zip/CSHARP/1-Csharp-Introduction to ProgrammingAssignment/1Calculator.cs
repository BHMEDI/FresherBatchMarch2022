﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1_Csharp_Introduction_to_ProgrammingAssignment
{
    public class Calculator
    {
        static void Main()
        {
            Console.WriteLine("enter the number1");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the number2");
            int num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the operator");
            String opereter = Console.ReadLine();
            switch (opereter)
            {

                case "+":
                    float num3 = num1 + num2;
                    Console.WriteLine("value is" + num3);
                    break;
                case "-":
                    num3 = num1 - num2;
                    Console.WriteLine("value is" + num3);
                    break;
                case "*":
                    num3 = num1 * num2;
                    Console.WriteLine("value is" + num3);
                    break;
                case "/":
                    num3 = num1 / num2;
                    Console.WriteLine("value is" + num3);
                    break;
                default:
                    Console.WriteLine("entered opreator is wrong");
                    break;
            }
                Console.ReadKey();
        }


    }
}
