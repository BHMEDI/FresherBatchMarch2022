﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1_Csharp_Introduction_to_ProgrammingAssignment
{
    internal class SwapNumbers
    {
        static void Main(String[] args)
        {
            swap();
        }
        static void swap()
        {
            Console.WriteLine("enter number1");
            int number1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter number2");
            int number2 = Convert.ToInt32(Console.ReadLine());        
            int temp = 0;

            temp = number1;
            number1 = number2;
            number2 = temp;
            Console.WriteLine("after swap {0},{1}", number1, number2);
            Console.ReadKey();
        }



    }
}
