﻿using System;
using System.Reflection;
using System.Linq;

namespace _8_CSharp_ReflectionAssignments
{
    [AttributeUsage(AttributeTargets.Class)]
    public class SoftwareAttribute : Attribute
    {
       
        private string ProjectName { get; set; }
     
        private string Description { get; set; }
       
        private string ClientName { get; set; }
        
        private string StartedDate { get; set; }
       
        private string EndDate { get; set; }
    }
    [Software()]
    public class HDFCACCOUNT
    {
        
        public int AccountID { get; set; }
       
        public string Name { get; set; }
    
        public int ACC_BAL { get; set; }

    }
    [Software()]
    public class ICICIACCOUNT
    {
       
        public int AccountID { get; set; }
        
        public string Name { get; set; }
       
        public int ACC_BAL { get; set; }

    }

    class Test
    {
        static void Main(string[] args)
        {
            var types = from t in Assembly.GetExecutingAssembly().GetTypes()
                        where t.GetCustomAttributes < SoftwareAttribute>().Count() > 0
                        select t;

            foreach (var t in types)
            {
                Console.WriteLine(t.Name);
                foreach(var p in t.GetProperties())
                {
                    Console.WriteLine(p.Name);
                }

            }
                
                Console.ReadKey();
        }

    }
}
