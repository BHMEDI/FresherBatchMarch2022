﻿using System;
using System.Reflection;
namespace _8_CSharp_ReflectionAssignments
{
    public class Reflection
    {
        private static void Main()
        {
            Assembly executingAssembly = Assembly.GetExecutingAssembly();

            Type type = executingAssembly.GetType("_8_CSharp_ReflectionAssignments.Class2");
            //To print types avalible in the assembly
            Console.WriteLine("Name : {0}", type.Name);
            Console.WriteLine("Full Name : {0}", type.FullName);
            Console.WriteLine("Namespace : {0}", type.Namespace);
            Console.WriteLine("Base Type : {0}", type.BaseType);
            // for Dyanamically invoking method at runtime
            object class2Instance = Activator.CreateInstance(type);

            MethodInfo getnameMethod = type.GetMethod("printname");

            string[] parameters = new string[1];

            parameters[0] = "bharat";

            string name = (string)getnameMethod.Invoke(class2Instance, parameters);
            Console.WriteLine(name);
            //TO PRINT METHODS THE ASSEMBLY 
            MethodInfo[] methods = type.GetMethods();
            foreach (MethodInfo method in methods)
            {
                Console.WriteLine(method.Name);
            }
            Console.ReadKey();
        }
    }
    public class Class2
    {
        public string printname(string name)
        {
            return name;
        }

    }
}
