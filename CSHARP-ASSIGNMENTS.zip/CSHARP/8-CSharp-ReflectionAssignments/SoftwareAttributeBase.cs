﻿namespace _8_CSharp_ReflectionAssignments
{
    public class SoftwareAttributeBase
    {
    }
}