﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5_CSharp_CollectionFramework_Assignmenst
{
     class Arraylist
    {
        public static void Main()
        {
            ArrayList obj = new ArrayList();
            Console.WriteLine("Employee Details Are");
            obj.Add(10);
            obj.Add("bharat kumar");
            obj.Add(5000);
            Console.WriteLine("Employee id is {0}", obj[0]);
            Console.WriteLine("Employee name is {0}", obj[1]);
            Console.WriteLine("Employee salary is {0}", obj[2]);
            Console.ReadKey();

        }


    }
}
