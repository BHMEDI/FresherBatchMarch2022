﻿using System;
using System.Collections;

namespace _5_CSharp_CollectionFramework_Assignmenst
{
    internal class Players
    {
        public string Player_Name { get; set; }
        public double Runs_scored { get; set; }

    }
    class Team : IEnumerable
    {
        ArrayList player_list = new ArrayList();
        public void Add(Players players) //for adding players
        {
            player_list.Add(players);
        }

         public IEnumerator GetEnumerator() //for iteration we use this method
         {
         return player_list.GetEnumerator();
         }
    }
        class client6
        {
           public static void Main()
            {
                Team india = new Team();
                india.Add(new Players { Player_Name = "bharat", Runs_scored = 50 });
                india.Add(new Players { Player_Name = "mani", Runs_scored = 60 });
                india.Add(new Players { Player_Name = "siddu", Runs_scored = 70 });
                india.Add(new Players { Player_Name = "jayant", Runs_scored = 80 });

                foreach(Players ind in india)
                {
                    Console.WriteLine(ind.Player_Name + " " + ind.Runs_scored);
                }
                Console.ReadLine();

            }
        }
    
}
