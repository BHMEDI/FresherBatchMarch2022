﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5_CSharp_CollectionFramework_Assignmenst
{
    internal class _3_GenaricList
    {
    static void Main()
        {
            List<string> list = new List<string>();
            list.Add("bharat");
            list.Add("maniraju");
            list.Add("siddu");
            list.Add("jayant");
            for (int i = 0; i < list.Count; i++)
            {
                Console.WriteLine("List of employees" + ':' + list[i]);
            }
            Console.WriteLine("total number of employess" +':'+ list.Count);
            Console.ReadLine();
        }
    }
}
