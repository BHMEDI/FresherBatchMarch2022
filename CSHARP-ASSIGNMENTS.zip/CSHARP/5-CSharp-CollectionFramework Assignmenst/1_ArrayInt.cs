﻿using System;
namespace _5_CSharp_CollectionFramework_Assignmenst
{
    public class Class1
    {
        public static int sizeInt;
        public static int max;
        static void integer()
        {
            int[] a1 = new int[sizeInt];
            Console.WriteLine("enter array elements");
            for (int i = 0; i < a1.Length; i++)
            {
                a1[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("sorted and array elements are");
            Array.Sort(a1);
            foreach (int j in a1)
            {
                Console.WriteLine(j);
            }
            Console.WriteLine("reversed array elements are");
            Array.Reverse(a1);
            foreach (int k in a1)
            {
                Console.WriteLine(k);

            }
            Console.WriteLine("array elements after clearing");
            Array.Clear(a1, 1, 2);
            foreach (int m in a1)
            {
                Console.WriteLine(m);
            }
            
            Console.WriteLine("after copying array elements");
            int[] array = new int[sizeInt];
            Array.Copy(a1, array, sizeInt);
            foreach (int n in array)
            {
                Console.WriteLine(n);
            }
        }
        static void StringArray()
        {
            string[] a2 = new string[max];
            Console.WriteLine("enter array elements");
            for (int i = 0; i < a2.Length; i++)
            {
                a2[i] = Console.ReadLine();
            }
            Console.WriteLine("sorted and array elements are");
            Array.Sort(a2);
            foreach (string j in a2)
            {
                Console.WriteLine(j);
            }
            Console.WriteLine("reversed array elements are");
            Array.Reverse(a2);
            foreach (string k in a2)
            {
                Console.WriteLine(k);

            }
            Console.WriteLine("array elements after clearing");
            Array.Clear(a2, 1, 2);
            foreach (string m in a2)
            {
                Console.WriteLine(m);
            }

            Console.WriteLine("after copying array elements");
            string[] array = new string[max];
            Array.Copy(a2, array, max);
            foreach (string n in array)
            {
                Console.WriteLine(n);
            }
        }
        static void Main()
        {
            Console.WriteLine("enter integer array size");
            sizeInt = Convert.ToInt32(Console.ReadLine());  
            integer();
            Console.WriteLine("enter string array size");
            max = Convert.ToInt32(Console.ReadLine());
            StringArray();
            Console.ReadLine();

        } 
    }
}
