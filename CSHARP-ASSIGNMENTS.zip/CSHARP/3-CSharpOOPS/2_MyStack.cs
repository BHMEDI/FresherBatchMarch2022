﻿using System;

namespace _3_CSharpOOPS
{
    internal class _2_MyStack
    {
        class Stack 
        {
            protected int max;
            public int[] element;
            private int top = -1;
            protected int i;
            public void push()
            {
                    Console.WriteLine("enter size of an array");
                    max = Convert.ToInt32(Console.ReadLine());
                    element = new int[max];
                    Console.WriteLine("enter elements");
                    for (i = 0; i < max; i++)
                    {
                        element[i] = Convert.ToInt32(Console.ReadLine());

                    }
                foreach (int b in element)
                {
                    if (top >= max)
                    {

                        Console.WriteLine("stackoverflow");
                        return;
                    }

                    else
                    {
                        element[++top] = b;
                    }
                }
            }
            public int pop()
            {
                if (top == -1)
                {
                    Console.WriteLine("Stack Underflow");
                    return -1;
                }
                else
                {
                    Console.WriteLine("Poped element is: " + element[top]);
                    return element[top--];
                }
            }
        }
        class Program
        {
            static void Main()
            {
                Stack S = new Stack();
                S.push();
                S.pop();
                S.pop();
                Console.ReadLine();
            }
        }
    }
}
