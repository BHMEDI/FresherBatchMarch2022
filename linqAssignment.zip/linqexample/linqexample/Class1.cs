﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace linqexample
{
    public class employee
    {
        public int EmployeeID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Title { get; set; }
        public DateTime DOB { get; set; }
        public DateTime DOJ { get; set; }
        public string City { get; set; }
    }

   public class Client
    {

      public static  List<employee> empList = new List<employee>()
{
//new Employee() {EmployeeID = 1001,FirstName = "Malcolm",LastName = "Daruwalla",Title = "Manager",DOB = DateTime.Parse("1984-01-02"),DOJ = DateTime.Parse("2011-08-09"),City = "Mumbai"},
//new Employee() {EmployeeID = 1002,FirstName = "Asdin",LastName = "Dhalla",Title = "AsstManager",DOB = DateTime.Parse("1984-08-20"),DOJ = DateTime.Parse("2012-7-7"),City = "Mumbai"},
//new Employee() {EmployeeID = 1003,FirstName = "Madhavi",LastName = "Oza",Title = "Consultant",DOB = DateTime.Parse("1987/11/14"),DOJ = DateTime.Parse("2015/4/12"),City = "Pune"},
//new Employee() {EmployeeID = 1004,FirstName = "Saba",LastName = "Shaikh",Title = "SE",DOB = DateTime.Parse("1990/6/3"),DOJ = DateTime.Parse("2016/2/2"),City = "Pune"},
//new Employee() {EmployeeID = 1005,FirstName = "Nazia",LastName = "Shaikh",Title = "SE",DOB = DateTime.Parse("1991/3/8"),DOJ = DateTime.Parse("2016/2/2"),City = "Mumbai"},
//new Employee() {EmployeeID = 1006,FirstName = "Suresh",LastName = "Pathak",Title = "Consultant",DOB = DateTime.Parse("1998/11/7"),DOJ = DateTime.Parse("2014/8/8"),City = "Chennai"},
//new Employee() {EmployeeID = 1007,FirstName = "Vijay",LastName = "Natrajan",Title = "Consultant",DOB = DateTime.Parse("1989/12/2"),DOJ = DateTime.Parse("2015/6/1"),City = "Mumbai"},
//new Employee() {EmployeeID = 1008,FirstName = "Rahul",LastName = "Dubey",Title = "Associate",DOB = DateTime.Parse("1993/11/11"),DOJ = DateTime.Parse("2014/11/6"),City = "Chennai"},
//new Employee() {EmployeeID = 1009,FirstName = "Amit",LastName = "Mistry",Title = "Associate",DOB = DateTime.Parse("1992/8/12"),DOJ = DateTime.Parse("2014/12/3"),City = "Chennai"},
//new Employee() {EmployeeID = 1010,FirstName = "Sumit",LastName = "Shah",Title = "Manager",DOB = DateTime.Parse("1991/4/12"),DOJ = DateTime.Parse("2016/1/2"),City = "Pune"},

 new employee() {EmployeeID = 1001,FirstName = "Malcolm",LastName = "Daruwalla",Title = "Manager",DOB = DateTime.Parse("1984-01-02"),DOJ = DateTime.Parse("2011-08-09"),City = "Mumbai"},
new employee() {EmployeeID = 1002,FirstName = "Asdin",LastName = "Dhalla",Title = "AsstManager",DOB = DateTime.Parse("1984-08-20"),DOJ = DateTime.Parse("2012-7-7"),City = "Mumbai"},
new employee() {EmployeeID = 1003,FirstName = "Madhavi",LastName = "Oza",Title = "Consultant",DOB = DateTime.Parse("1987-11-14"),DOJ = DateTime.Parse("2015-4-12"),City = "Pune"},
new employee() {EmployeeID = 1004,FirstName = "Saba",LastName = "Shaikh",Title = "SE",DOB = DateTime.Parse("6/3/1990"),DOJ = DateTime.Parse("2/2/2016"),City = "Pune"},
new employee() {EmployeeID = 1005,FirstName = "Nazia",LastName = "Shaikh",Title = "SE",DOB = DateTime.Parse("3/8/1991"),DOJ = DateTime.Parse("2/2/2016"),City = "Mumbai"},
new employee() {EmployeeID = 1006,FirstName = "Suresh",LastName = "Pathak",Title = "Consultant",DOB = DateTime.Parse("11/7/1989"),DOJ = DateTime.Parse("8/8/2014"),City = "Chennai"},
new employee() {EmployeeID = 1007,FirstName = "Vijay",LastName = "Natrajan",Title = "Consultant",DOB = DateTime.Parse("12/2/1989"),DOJ = DateTime.Parse("6/1/2015"),City = "Mumbai"},
new employee() {EmployeeID = 1008,FirstName = "Rahul",LastName = "Dubey",Title = "Associate",DOB = DateTime.Parse("11/11/1993"),DOJ = DateTime.Parse("11/6/2014"),City = "Chennai"},
new employee() {EmployeeID = 1009,FirstName = "Amit",LastName = "Mistry",Title = "Associate",DOB = DateTime.Parse("8/12/1992"),DOJ = DateTime.Parse("12/3/2014"),City = "Chennai"},
new employee() {EmployeeID = 1010,FirstName = "Sumit",LastName = "Shah",Title = "Manager",DOB = DateTime.Parse("4/12/1991"),DOJ = DateTime.Parse("1/2/2016"),City = "Pune"},

};





    static void Main()
        {
            // Displayall();
            // Notmubmai();
            // LastNameS();
            // JoinedBefore1115();
            //TotalEmployess();
            // Highestemployeeid();
            //JoinedBefore1115()
            //Dobafter1190()
            //TotalEmployess()
            //Dobafter1190()
            //TotalBasedOnMumbai()
            //TotalBasedOnCity()
            //TotalNotAssociate()
            TotalBasedOnChennai();

            Console.ReadLine();

        }
       public static void Displayall()
        {
            var emp =from i in empList select i;
            foreach (var item in emp)
            {

                Console.WriteLine(item.EmployeeID+""+item.FirstName+""+item.LastName+""+item.Title+""+item.City+""+item.DOB+""+item.DOJ);
            }
        }
        public static void Notmubmai()
        {
            var emp = from i in empList where i.City !="mumbai" select i;
            foreach (var item in emp)
            {

                Console.WriteLine(item.EmployeeID + "" + item.FirstName + "" + item.LastName + "" + item.Title + "" + item.City + "" + item.DOB + "" + item.DOJ);
            }

        }
   
        public static void AsstManager()
        {
            var emp = from i in empList where i.Title != "AsstManager" select i;
            foreach (var item in emp)
            {

                Console.WriteLine(item.EmployeeID + "" + item.FirstName + "" + item.LastName + "" + item.Title + "" + item.City + "" + item.DOB + "" + item.DOJ);
            }

        }
        public static void LastNameS()
        {
            var emp = from i in empList where i.LastName.StartsWith("S") select i;
            foreach (var item in emp)
            {

                Console.WriteLine(item.EmployeeID + "" + item.FirstName + "" + item.LastName + "" + item.Title + "" + item.City + "" + item.DOB + "" + item.DOJ);
            }


        }
        public static void JoinedBefore1115()
        {
            var emp = from i in empList where i.DOJ <= DateTime.Parse("2015-01-01") select i;

            foreach (var item in emp)
            {

                Console.WriteLine(item.EmployeeID + "" + item.FirstName + "" + item.LastName + "" + item.Title + "" + item.City + "" + item.DOB + "" + item.DOJ);
            }
        }
        public static void Dobafter1190()
        {
            var emp = from i in empList where i.DOB >DateTime.Parse("1990-01-01") select i;

            foreach (var item in emp)
            {

                Console.WriteLine(item.EmployeeID + "" + item.FirstName + "" + item.LastName + "" + item.Title + "" + item.City + "" + item.DOB + "" + item.DOJ);
            }

        }
        public static void ConsultantAssociate()
        {
            var emp = from i in empList where i.Title=="Consultant"&&i.Title=="Associate"  select i;

            foreach (var item in emp)
            {

                Console.WriteLine(item.EmployeeID + "" + item.FirstName + "" + item.LastName + "" + item.Title + "" + item.City + "" + item.DOB + "" + item.DOJ);
            }
        }
        public static void TotalEmployess()
        {
            var emp = from i in empList select i;

            Console.WriteLine(emp.Count());
        }
        public static void Highestemployeeid()
        {
            var emp = empList.Max(i => i.EmployeeID);
            Console.WriteLine(emp);

        }
        public static void TotalJoinedAfter1115()
        {
            var emp = from i in empList where i.DOB > DateTime.Parse("2015-01-01") select i;
            Console.WriteLine(emp.Count());
        }
        public static void TotalNotAssociate()
        {
            var emp = from i in empList where i.Title !="Associate" select i;
            Console.WriteLine(emp.Count());
        }
        public static void TotalBasedOnMumbai()
        {
            var emp = from i in empList where i.City =="Mumbai" select i;
            Console.WriteLine(emp.Count());
        }
        public static void TotalBasedOnChennai()
        {
            var emp = from i in empList where i.City == "Chennai" select i;
            Console.WriteLine(emp.Count());
        }
        public static void TotalBasedOnPune()
        {
            var emp = from i in empList where i.City == "Pune" select i;
            Console.WriteLine(emp.Count());
        }
        public static void TotalBasedOnCity()
        {
            var emp = from i in empList where i.City == "Mumbai" && i.Title == "Associate" select i;
            Console.WriteLine(emp.Count());
        }









    }





}

