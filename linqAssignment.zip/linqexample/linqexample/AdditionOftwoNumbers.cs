﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace linqexample
{
    internal class AdditionOftwoNumbers
    {
        static void Main()
        {
            int a = 10;
            int b = 20;
            Console.WriteLine(a + b);

        }
    }
}

